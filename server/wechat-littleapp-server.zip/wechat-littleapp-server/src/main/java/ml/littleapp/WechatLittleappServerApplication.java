package ml.littleapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WechatLittleappServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(WechatLittleappServerApplication.class, args);
	}
}
